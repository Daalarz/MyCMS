<?php
$CONFIG['db_host']		=		'localhost';
$CONFIG['db_name']		=		'mycms';
$CONFIG['db_user']		=		'root';
$CONFIG['db_pass']		=		'';
$CONFIG['db_prefix']		=		'phg_';

?>