<?php
/*****************

Скрипт установки

******************/

define ( 'INSTALL_PATH', './' );
define ( 'ROOT_PATH', '../' );
define ( 'KERNEL_PATH', '../kernel/' );

require KERNEL_PATH."class_html.php";

$html = new html_install;
	
if (!isset ($_POST['control']) or empty ($_POST['control']))
{
	$html->do_form(); // если не введен параметр "ОК" - форма инсталляции
}
else // если передан параметр "control"...
{ 
	if ($_POST['control'] == "OK") // если пользователь согласен на установку - проверка заполнения полей
	{
		if (!empty ($_POST['db_host']) &&
			!empty ($_POST['db_name']) &&
			!empty ($_POST['db_user']) &&
			!empty ($_POST['db_prefix']) &&
			!empty ($_POST['user']) && 
			!empty ($_POST['pass']) &&
			!empty ($_POST['passw'])
			) // все заполнено - проверка корректности паролей
		{
			if ($_POST['pass'] == $_POST['passw']) // если пароли набраны корректно - установка
			{
				// вызываем движок БД
				include KERNEL_PATH."class_mysql_engine.php";
				$db = new db_engine;
				
				$pass = $_POST['pass'];
				$user = $_POST['user'];
				$pass_md5 = md5($pass);
				
				// параметры коннекта с БД
				$db->host = $_POST['db_host'];
				$db->user = $_POST['db_user'];
				$db->pass = $_POST['db_pass'];
				$db->name = $_POST['db_name'];
				
				// заносим введенные данные в массив $CONFIG
				
				$CONFIG = array (
					'db_host' => $_POST['db_host'],
					'db_name' => $_POST['db_name'],
					'db_user' => $_POST['db_user'],
					'db_pass' => $_POST['db_pass'],
					'db_prefix' => $_POST['db_prefix'],
				);
				
				// формируем содержимое файла config.php
				
				$conf = "<"."?php\n";
					
				foreach ($CONFIG as $key => $val) // перебор...
				{
					$conf .= '$CONFIG['."'".$key."'".']'."\t\t=\t\t'".$val."';\n";
				}
				
				$conf .= "\n".'?'.'>';
				
				// пишем файл конфигурации...
				
				if ($f = fopen(KERNEL_PATH."config.php", 'w'))
				{
					fputs($f, $conf, strlen($conf));
					fclose($f);
				}
				else
				{
					$html->notice("Невозможна запись в файл конфигурации config.php");
				}
				
				// соединяемся с БД
				/*if ( !*/$db->connect(); //)
				/*{
					$db->error();
				}*/
				
				/*if ( !$db->connect(); //)
				{
					$db->error();
				}*/

				// вызываем запросы БД

				require INSTALL_PATH.'creates.php';
				
				foreach ($CREATE as $query) // перебор...
				{
					if ($_POST['db_prefix'] != "phg_") // если префикс таблиц не соответствует префиксу по дефолту (phg_) - меняем на введенный
			        {
						$query = preg_replace("/phg_(\S+?)([\s\.,]|$)/", $_POST['db_prefix']."\\1\\2", $query);
			        }
					
					/*if(!*/$db->query($query);/*)*/ // запрос...
					/*{
						$db->error();
					}*/
				}
				
				require INSTALL_PATH.'inserts.php';
	
				foreach ($INSERT as $query) // перебор...
				{
					if ($_POST['db_prefix'] != "phg_") // если префикс таблиц не соответствует префиксу по дефолту (phg_) - меняем на введенный
			        {
						$query = preg_replace("/phg_(\S+?)([\s\.,]|$)/", $_POST['db_prefix']."\\1\\2", $query);
			        }
					
					/*if(!*/$db->query($query);/*) */// запрос...
					/*{
						$db->error();
					}*/
				}

				$html->do_finish();
				
			}
			else // если пароли разные - перенабрать
			{ 
				$html->notice("Набранные пароли администратора Фотогалереи не соответствуют друг другу");
			}
		}
		else // если поля не заполнены - заполнить!
		{ 
			$html->notice("Не заполнены обязательные к заполнению поля в форме инсталляции Фотогалереи");
		}
	}
	else // если пользователь вписал вместо "OK" что-то еще
	{ 
		$html->notice("Неизвестный параметр: $control");
	}
}

?>