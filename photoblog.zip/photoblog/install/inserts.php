<?php
$INSERT[] = "INSERT INTO phg_sys_users VALUES (0,'$user','$pass_md5')";
?>
