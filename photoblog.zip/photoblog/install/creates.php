<?php
$CREATE[] = "CREATE TABLE phg_sys_albums (
	album_id INT NOT NULL AUTO_INCREMENT, 
	album_name TINYTEXT NOT NULL, 
	create_date TINYTEXT NOT NULL,
	description TINYTEXT NOT NULL,
	PRIMARY KEY (album_id)
)";
			
$CREATE[] = "CREATE TABLE phg_sys_temp (
	photo_id INT NOT NULL AUTO_INCREMENT, 
	photo_name TINYTEXT NOT NULL, 
	PRIMARY KEY (photo_id)
)";
				
$CREATE[] = "CREATE TABLE phg_sys_users (
	user_id INT NOT NULL AUTO_INCREMENT,
	user TINYTEXT NOT NULL, 
	pass TINYTEXT DEFAULT NULL, 
	PRIMARY KEY (user_id)
)";
				
$CREATE[] = "CREATE TABLE phg_sys_auth_err (
	id INT NOT NULL AUTO_INCREMENT, 
	ip TINYTEXT NOT NULL, 
	user TINYTEXT DEFAULT NULL, 
	pass TINYTEXT DEFAULT NULL, 
	date TINYTEXT NOT NULL,
	script TINYTEXT DEFAULT NULL,
	agent TINYTEXT DEFAULT NULL,
	PRIMARY KEY (id)
)";

$CREATE[] = "CREATE TABLE phg_sys_photos (
	photo_id INT NOT NULL AUTO_INCREMENT,
	photo_name TINYTEXT NOT NULL,
	desc_name TINYTEXT NOT NULL,
	album_id TINYTEXT NOT NULL,
	upload_date TINYTEXT NOT NULL,
	description TEXT DEFAULT NULL,
	PRIMARY KEY (photo_id)
)";

?>