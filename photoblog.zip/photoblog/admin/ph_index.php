<?php

// установка путей 
define ( 'ROOT_PATH', '../' );
define ( 'KERNEL_PATH', '../kernel/' );
define ( 'THUMB_PATH', '../uploads/thumb/' );
define ( 'SMALL_PATH', '../uploads/small/' );
define ( 'BIG_PATH', '../uploads/big/' );

require_once KERNEL_PATH."config.php";

require_once KERNEL_PATH."class_html.php";
$html = new html_admin;

// соединяемся с сессией...
if (isset ($_COOKIE['phg_sid']))
{
	session_id($_COOKIE['phg_sid']);
	session_start();
}

if (isset ($_SESSION['user']) && !empty ($_SESSION['user'])) // если существует имя юзера и непусто
{
	require_once KERNEL_PATH."class_mysql_engine.php";
	$db = new db_engine;
	
	// выясняем названия таблиц с учетом префикса и подгоняем под шаблон tbl_
	$tbl_sys_users = $CONFIG['db_prefix']."sys_users";
	$tbl_sys_auth_err = $CONFIG['db_prefix']."sys_auth_err";
	$tbl_sys_temp = $CONFIG['db_prefix']."sys_temp";
	$tbl_sys_albums = $CONFIG['db_prefix']."sys_albums";
	$tbl_sys_photos = $CONFIG['db_prefix']."sys_photos";
	
	$db->host = $CONFIG['db_host'];
	$db->user = $CONFIG['db_user'];
	$db->pass = $CONFIG['db_pass'];
	$db->name = $CONFIG['db_name'];
	
	/*if ( !$db->server_connect() )
	{
		$db->error();
	}*/
	
	if (!$db->connect())
	{
		$db->error();
	}
	
	$db->query_array("SELECT user, pass FROM $tbl_sys_users WHERE user_id=1");
	

	// выясняем реальный логин и пароль админа
	$R_psswd = $db->req_array['pass']; // из таблицы
	$R_user = $db->req_array['user']; // из таблицы
	
	$ip = $_SERVER['REMOTE_ADDR'];
	$strid = md5($_SERVER['HTTP_USER_AGENT'].$_SERVER['HTTP_ACCEPT']);
	
	// выясняем данные сессии
	$pass = $_SESSION['pass']; // из сессии
	$user = $_SESSION['user']; // из сессии
	$s_ip = $_SESSION['ip'];
	$str = $_SESSION['strid'];

	
	if ($R_user == $user &&
		$R_psswd == $pass &&
		$ip == $s_ip &&
		$strid == $str) // если все данные совпадают - ACCESS! :)
	{

		// выбираем все альбомы из таблицы альбомов

		if (!isset ($_GET['p']) or empty ($_GET['p']))
		{
			$p = 1;
		}
		else
		{
			$p = $_GET['p'];
		}

		$lim = 3*$p-3;
		
		echo ("
			<html>
			<head>

			<style type = 'text/css'>
			@import url('../css/admin.css');
			</style>
			</head>
			<script type='text/javascript' src='./alert.js'></script>
			<body>
			<center>
			<div class='header'>Главная страница Фотогалереи (режим администратора)</div><br /><br />
			<table cellpadding='5' cellspacing='1'>
				<tr>
				<td>
		");

		$query = $db->query ("SELECT album_name, album_id FROM $tbl_sys_albums LIMIT $lim,3");
		$table_num_rows = $db->num_rows ("SELECT album_id FROM $tbl_sys_albums");
		
		$i=0;
		while ($albums = $ db->fetch_assoc ($query))
		{ // в цикле выводим  каждый альбом...


			$i++;
			$album_name = $albums['album_name'];
			$album_id = $albums['album_id'];

			// выводим альбом...
			$html = <<<EOF
			<table cellpadding='5' cellspacing='1'>
				<tr>
					<th colspan='5' align='left'>
						$album_name &nbsp; 
						[ <a href = './showalbum.php?alb_id=$album_id'>Перейти в альбом</a> |
						 <a href = './delalbum.php?alb_id=$album_id' id='alertLink'>Удалить</a> ]
					</th>
					
					
				</tr><tr> 
EOF;

			echo $html;
			unset ($html);
			
			// дальше - вывод в следующей строке таблицы последних загруженных изображений
			
			$r = $db->query ("SELECT photo_name FROM $tbl_sys_photos WHERE album_id='$album_id' ORDER BY photo_id DESC LIMIT 5");
			while ($req_array = $db->fetch_array ($r))
			{
				$thumb_name = THUMB_PATH.$req_array['photo_name'];
				echo ("<td align='center'><img src='$thumb_name' /></td>");
			}
			
			
			
			$num_rows = $db->num_rows ($r);
			if (empty ($num_rows))
			{ 
				echo ("<td><div class='notice'>В альбоме нет фотографий</div></td>");
			}
			
			echo ("</tr></table>");
	
			if ($i != 3)
			{
				echo ("<br />");
			}
			
			
			
		}

		echo ("
			</td>
			</tr>
			</table>
			<br /><br />
			<p style='width: 1100px; text-align: left;'>
		");

		$num_pages = ceil($table_num_rows / 3);
		if ($num_pages > 1)
		{
			echo ("Страницы (".$num_pages.") :");
							
			$i = 1;
			while ($i <= ($num_pages))
			{
				if ($i == $p)
				{
					echo ("&nbsp;<b>[".$i."]</b>");
				}
				else
				{
					echo ("&nbsp;<a href='".ROOT_PATH."admin/ph_index.php?p=".$i."'>".$i."</a>");	
				}
				$i++;
			}
							
		}
		
		echo ("
			</p>
			</center>
			</body>
			</html>
		");
		
	}
	else
	{
		header ("location: ../index.php");
	}
	
}
else
{
	$html->notice("Сесии администратора не найдено");
}

?>