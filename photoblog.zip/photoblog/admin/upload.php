<?php

// установка путей 
define ( 'ROOT_PATH', '../' );
define ( 'KERNEL_PATH', '../kernel/' );
define ( 'THUMB_PATH', '../uploads/thumb/' );
define ( 'SMALL_PATH', '../uploads/small/' );
define ( 'BIG_PATH', '../uploads/big/' );

require_once KERNEL_PATH."config.php";

require KERNEL_PATH."class_html.php";
$html = new html_admin;

// соединяемся с сессией...
if (isset ($_COOKIE['phg_sid']))
{
	session_id($_COOKIE['phg_sid']);
	session_start();
}

if (isset ($_SESSION['user']) && !empty ($_SESSION['user'])) // если существует имя юзера и непусто
{
	require KERNEL_PATH."class_mysql_engine.php";
	$db = new db_engine;
	
	// выясняем названия таблиц с учетом префикса и подгоняем под шаблон tbl_
	$tbl_sys_users = $CONFIG['db_prefix']."sys_users";
	$tbl_sys_auth_err = $CONFIG['db_prefix']."sys_auth_err";
	$tbl_sys_temp = $CONFIG['db_prefix']."sys_temp";
	$tbl_sys_albums = $CONFIG['db_prefix']."sys_albums";
	$tbl_sys_photos = $CONFIG['db_prefix']."sys_photos";
	
	$db->host = $CONFIG['db_host'];
	$db->user = $CONFIG['db_user'];
	$db->pass = $CONFIG['db_pass'];
	$db->name = $CONFIG['db_name'];
	
	/*if ( !$db->server_connect() )
	{
		$db->error();
	}*/
	
	if (!$db->connect())
	{
		$db->error();
	}
	
	$db->query_array("SELECT user, pass FROM $tbl_sys_users WHERE user_id=1");
	

	// выясняем реальный логин и пароль админа
	$R_psswd = $db->req_array['pass']; // из таблицы
	$R_user = $db->req_array['user']; // из таблицы
	
	$ip = $_SERVER['REMOTE_ADDR'];
	$strid = md5($_SERVER['HTTP_USER_AGENT'].$_SERVER['HTTP_ACCEPT']);
	
	// выясняем данные сессии
	$pass = $_SESSION['pass']; // из сессии
	$user = $_SESSION['user']; // из сессии
	$s_ip = $_SESSION['ip'];
	$str = $_SESSION['strid'];

	
	if ($R_user == $user &&
		$R_psswd == $pass &&
		$ip == $s_ip &&
		$strid == $str) // если все данные совпадают - ACCESS! :)
	{
		if (!isset ($_FILES["photo"]["name"])) // если файл не был загружен - форма для загрузки
		{ 
			$html->do_upload_form();
		}
		else // результат загрузки
		{								
			$ext = strrchr($_FILES['photo']['name'], ".");

			if ($ext == ".jpeg" or $ext == ".jpg" or $ext == ".JPG" or $ext == ".JPEG") // если расширения соответствуют допустимым - добавление
			{ 
				if(copy ($_FILES["photo"]["tmp_name"], BIG_PATH.$_FILES["photo"]["name"])) // копирование прошло успешно - создание уменьшенной копии и занесение в БД
				{ 
					$ph_name = $_FILES["photo"]["name"];
					
					$html->ph_size = $_FILES["photo"]["size"];
					$html->ph_name = $_FILES["photo"]["name"];
					
					//=====================
					// RESIZE BLOCK BEGIN
					//=====================
						
					$filename = BIG_PATH.$ph_name;
					$thumbname = THUMB_PATH.$ph_name;
					$w = 150;
					$h = 150;
					
					require_once KERNEL_PATH."resize.php";
					
					resizeimg ($filename, $thumbname, $w, $h);
					
					//===================
					// RESIZE BLOCK END
					//===================
					
					//=====================
					// RESIZE BLOCK BEGIN
					//=====================
						
					$filename = BIG_PATH.$ph_name;
					$smallname = SMALL_PATH.$ph_name;
					$w = 600;
					$h = 600;
					
					require_once KERNEL_PATH."resize.php";
					
					resizeimg ($filename, $smallname, $w, $h);
					
					//===================
					// RESIZE BLOCK END
					//===================
					
					$html->thumb_name = $thumbname;
					$html->upload_result(1);
					
					// выбираем из БД все существующие альбомы: таблица albums
					
					// $i = $db->num_rows ("SELECT * FROM $tbl_sys_albums");
					
					$r = $db->query ("SELECT album_id, album_name FROM $tbl_sys_albums");
					
					while ($req_array = $db->fetch_array ($r)) // в цикле выводим варианты select'а
					{ 
						echo ("<option value = '".$req_array["album_id"]."'>".$req_array["album_name"]."</option>");
						//$req_array = $html->req_array;
						//$html->upload_result(2);
						
						
					}
					
					$html->upload_result(3);
					
					
					$db->query("INSERT INTO $tbl_sys_temp VALUES (0, '$ph_name')");
				}
				else
				{
					$html->notice("Ошибка загрузки файла");
				}
			}
			else
			{
				$html->notice("Неверный тип загружаемого файла");
			}
		}
	}
	else // если логин и пароль не совпадают - привет, хацкер! :)
	{ 
		header ("location: ../index.php");
	}
}
else
{
	$html->notice("Сесии администратора не найдено");
}

?>