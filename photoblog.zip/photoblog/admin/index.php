<?php

// Индексный скрипт админки

define ( 'ROOT_PATH', '../' );
define ( 'KERNEL_PATH', '../kernel/' );

require_once KERNEL_PATH."config.php";

require KERNEL_PATH."class_html.php";
$html = new html_admin;

$html->script_name = $_SERVER["SCRIPT_NAME"];

if (!isset ($_POST['uname']) or empty ($_POST['uname'])) // если форма авторизации не заполнена - заполнить!
{ 
	$html->do_auth();
}
else // если авторизация прошла - выборка из таблицы phg_users логина и пароля, перевод в md5 введенного пароля для сравнения
{ 
	require KERNEL_PATH."class_mysql_engine.php";
	$db = new db_engine;
	
	// инициализация таблиц
	$tbl_sys_users = $CONFIG['db_prefix']."sys_users";
	$tbl_sys_auth_err = $CONFIG['db_prefix']."sys_auth_err";
	
	$db->host = $CONFIG['db_host'];
	$db->user = $CONFIG['db_user'];
	$db->pass = $CONFIG['db_pass'];
	$db->name = $CONFIG['db_name'];
	
	/*if ( !$db->server_connect() )
	{
		$db->error();
	}*/
	
	if (!$db->connect())
	{
		$db->error();
	}
	
	$db->query_array("SELECT user, pass FROM $tbl_sys_users WHERE user_id=1");
	

	$R_psswd = $db->req_array['pass']; // из таблицы
	$R_user = $db->req_array['user']; // из таблицы
	
	$psswd = $_POST['psswd']; // из формы
	$A_user = $_POST['uname']; // из формы

	$A_psswd = md5($psswd); 

	if ($R_user == $A_user && $R_psswd == $A_psswd) // если введенные данные и данные из таблицы phg_users совпадают - ACCESS! :)
	{ 
		// start sessions

 function session_register()
 {
    $args = func_get_args();
    foreach ($args as $key)
    {
       if (!isset($GLOBALS[$key])) 
       {
          $GLOBALS[$key] = NULL;
       }
       $_SESSION[$key] =& $GLOBALS[$key];
    }
 }

		session_name("phg_sid");
		session_start();
		session_register("user");
		session_register("pass");
		session_register("ip");
		session_register("strid");
		
		$_SESSION['user'] = $A_user;
		$_SESSION['pass'] = $A_psswd;
		$_SESSION['ip'] = $_SERVER['REMOTE_ADDR'];
		$_SESSION['strid'] = md5($_SERVER['HTTP_USER_AGENT'].$_SERVER['HTTP_ACCEPT']);
		
		$html->do_admin_index();
	}
	 else // если логин и пароль не совпадают - привет, хацкер! :)
	{ 
			
		$ip = $_SERVER["REMOTE_ADDR"];
		$date = date("d.m.Y в H:i:s");
		$agent = $_SERVER["HTTP_USER_AGENT"];
		$script = $_SERVER["SCRIPT_NAME"];
		
		$db->query (
			"INSERT INTO $tbl_sys_auth_err VALUES (
				0,
				'$ip',
				'$A_user',
				'$psswd',
				'$date',
				'$script',
				'$agent'
			)"
		);
		
		
		header ("location: ../index.php");
	} 
}

?>